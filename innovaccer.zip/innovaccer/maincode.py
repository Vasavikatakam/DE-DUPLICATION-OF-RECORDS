import csv
from sklearn.cluster import KMeans
from jarowinkler import jarowinkler
numericlist=[]
def radixconversion(item):
    	sum1=0
	len1=len(item)
	count=1
	for i in range(0,len1):
		if(65<=ord(item[i])<=90):
			sum1=sum1+((pow(37,len1-count)*(ord(item[i])-55))%731)
		elif(48<=ord(item[i])<=57):
			sum1=sum1+((pow(37,len1-count)*(ord(item[i])-ord('0')))%731)
		elif(item[i]==' '):
			sum1=sum1+((pow(37,len1-count)*(36))%731)
		elif(item[i]=='/'):
			sum1=sum1+((pow(37,len1-count)*(36))%731)
		count=count+1
	return sum1	
allrecords=[]			

with open('input.csv') as csvfile:                     
	readcsv=csv.reader(csvfile,delimiter=',')
	count1=0
	for row in readcsv:
		if(count1>0):
			dummy=[]
			dummy1=[]
			for item in row:	
				dummy1.append(item)
				r=[]
				r=item.split(' ')
				item=""
				for k in r:
					item=item+k	
				#print(item)
				k=radixconversion(item)
 				dummy.append(k)
			sum1=0
			for item in dummy:
				sum1=sum1+radixconversion(str(item))
			dummy.append(sum1)
			numericlist.append(dummy)
			allrecords.append(dummy1)
		count1=count1+1
#print(numericlist)
kmeans = KMeans(n_clusters=1)                            #applying k means on this you can change the n_clusters and check the performance
finalscore=[]
for item in numericlist:
	finalscore.append([item[4]])
kmeans = kmeans.fit(finalscore)
labels = kmeans.predict(finalscore)
n=len(allrecords)
#feature vector generation
featurevector=[]
for i in range(0,n-1):
	for j in range(i+1,n):
		if(labels[i]==labels[j]):
			dummy=[]
			dummy.append(i+1)
			dummy.append(j+1)	
			for k in range(0,len(numericlist[i])-1):
				if(numericlist[i][k]==numericlist[j][k]):
					dummy.append(1)
				else:
					val=jarowinkler(allrecords[i][k],allrecords[j][k])
					if(val>=0.85):
						dummy.append(1)
					else:
						dummy.append(0)	
			featurevector.append(dummy)
matches=[]
#print("feature vector:")
#print(featurevector)
for i in featurevector:
	sum1=0
	for j in range(2,len(i)):
		sum1=sum1+i[j]
	dummy=[]
	if(sum1==4):
		dummy.append(i[0])
		dummy.append(i[1])
		matches.append(dummy)

matchdicts={}
for i in matches:
	if i[0] in matchdicts.keys():
		matchdicts[i[0]].append(i[1])
	else:
		matchdicts[i[0]]=[]
		matchdicts[i[0]].append(i[1])
for i in range(1,len(allrecords)+1):
	if i not in matchdicts.keys():
		matchdicts[i]=[]


for i in matchdicts.keys():
	if i in matchdicts.keys():
		for k in matchdicts[i]:
			if k in matchdicts.keys():
				del matchdicts[k]
print("no of unique records:")
print(len(matchdicts.keys()))
print("Unique records:")
final=[]
for record in matchdicts.keys():
	final.append(allrecords[record-1])
	print(allrecords[record-1])
#print(final)	
#writing output into the file
myFile = open('output.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(final)	
		

									
				

	     
       


