#s1=raw_input()
#s2=raw_input()

def jarowinkler(s1,s2):
	count=0
	trans=0
	if(len(s1)>=len(s2)):
		meas=(len(s1)/2)-1
       	else:
                meas=(len(s2)/2)-1
	for i in range(0,len(s1)):
		for j in range(0,len(s2)):
			if(s1[i]==s2[j]):
				if(abs(i-j)<=meas):
					count=count+1
					if(i!=j):
						trans=trans+1
					break
	                                
	#print("m")
	#print(count)

	trans=trans/2
	#print("t")
	#print(trans)
	if(count==0):
		jarosim=0
	else:
		jarosim=((float(count)/float(len(s1)))+(float(count)/float(len(s2)))+(float(count-trans)/float(count)))/3.0
	#print("jarosim")
	#print(jarosim)
	l=0	
	if(len(s1)<=len(s2)):
		for i in range(0,len(s1)):
			if(s1[i]==s2[i]):
				l=l+1
			else:
				break
	else:
		for i in range(0,len(s2)):
                        if(s2[i]==s1[i]):
                                l=l+1
                        else:
                                break
	if(l>=4):
		l=4
	jarowinklersim=jarosim+(l*0.1*(1-jarosim))
	return jarowinklersim

#jarowinkler(s1,s2)

		
	
